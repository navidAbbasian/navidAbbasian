


<h1 align="center">Hi 👋, I'm Navid</h1>
<h3 align="center">Mobile / Web Developer</h3>
<p align="center">Born In 1996, Graduated in IT major and Studied Android Development. interested in teamwork and having new team experiences and ideas,
unnstopable in researching and learning ... </p>

---


<img align="right" alt="Coding" width="400" src="https://user-images.githubusercontent.com/51839181/185767009-04421265-3c0d-48e5-bb5c-d11c8b14bd7d.gif">





<p align="left"> <img src="https://komarev.com/ghpvc/?username=navidabbasian&label=Profile%20views&color=0e75b6&style=flat" alt="navidabbasian" /> </p>

<p align="left"> <a href="https://twitter.com/navid_abn" target="blank"><img src="https://img.shields.io/twitter/follow/navid_abn?logo=twitter&style=for-the-badge" alt="navid_abn" /></a> </p>

- 🔭 I’m currently working in [Livekala Team](https://github.com/orgs/livekala/teams/livekala)

- 🌱 I’m currently learning **docker and microservice architecture**

- 👨‍💻 All of my projects are available at [My Personal Website](https://navidabbasian.github.io/)

- 💬 Ask me about **Programing And Cryptocurrency**

- 📫 How to reach me **abbasian.navid@gmail.com**


<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://twitter.com/navid_abn" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="navid_abn" height="30" width="40" /></a>
<a href="https://linkedin.com/in/navid-abbasian" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="navid-abbasian" height="30" width="40" /></a>
</p>

